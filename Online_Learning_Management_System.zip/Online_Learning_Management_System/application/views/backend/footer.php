<!-- Footer -->
<footer class="main">
	<strong> <?php echo get_settings('system_name'); ?> </strong> | &copy; 2018,
	<a href="<?php echo get_settings('footer_link'); ?>"
    	target="_blank"><?php echo get_settings('footer_text'); ?></a>
</footer>
